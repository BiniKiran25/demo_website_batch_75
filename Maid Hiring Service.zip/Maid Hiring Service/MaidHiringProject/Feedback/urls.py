from django.urls import path
from . views import *

app_name = 'Feedback'

urlpatterns = [
    path('single_profile/<int:maid_id>/', Single_Profile, name='single_profile'),
    path('feedbacks/', Maid_Feedbacks, name='maid_feedback'),
]