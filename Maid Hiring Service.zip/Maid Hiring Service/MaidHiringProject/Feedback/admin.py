from django.contrib import admin
from .models import Feedback

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('customer__first_name', 'maid', 'comment', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('maid__first_name', 'customer__first_name', 'comment')
    ordering = ('-created_at',)
    readonly_fields = ('created_at',)

