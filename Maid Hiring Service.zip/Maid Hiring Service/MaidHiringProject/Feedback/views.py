from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from Maid.models import MaidDetails
from . models import Feedback
from .forms import FeedbackForm



@login_required(login_url='Customer:customer_login')
def Single_Profile(request, maid_id):
    maid = get_object_or_404(MaidDetails, id=maid_id)
    feedbacks = maid.feedbacks.filter(maid=maid).order_by('-created_at')
    feedback_form = FeedbackForm()

    if request.method == 'POST':
        feedback_form = FeedbackForm(request.POST)
        if feedback_form.is_valid():
            feedback = feedback_form.save(commit=False)
            feedback.maid = maid
            feedback.customer = request.user
            feedback.save()
            return redirect('Feedback:single_profile', maid_id=maid.id.pk)

    context = {
        'maid': maid,
        'feedbacks': feedbacks,
        'feedback_form': feedback_form,
        'star_range': range(1, 6),
    }
    return render(request, 'Customer/Maid_Single_Profile.html', context)



@login_required(login_url='Maid:maid_login')
def Maid_Feedbacks(request):
    maid = get_object_or_404(MaidDetails, id=request.user.id)
    feedbacks = maid.feedbacks.all().order_by('-created_at')
    context = {
        'feedbacks': feedbacks,
        'star_range': range(1, 6),
    }
    return render(request, 'Maid/View_Feedback.html', context)

