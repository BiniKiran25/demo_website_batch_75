from django.db import models
from django.contrib.auth.models import User
from Maid.models import MaidDetails


class Feedback(models.Model):
    maid = models.ForeignKey(MaidDetails, on_delete=models.CASCADE, related_name="feedbacks")
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.TextField()
    rating = models.PositiveIntegerField(default=1, choices=[(i, i) for i in range(1, 6)])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.customer.first_name} for {self.maid.first_name}"