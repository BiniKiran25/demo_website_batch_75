from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from Maid.models import MaidDetails
# Create your views here.


@login_required(login_url='Customer:login')
def View_Maid(request):
    maids = MaidDetails.objects.filter(is_approved=True)
    return render(request, 'Booking/All_Maid.html', {'maids': maids})