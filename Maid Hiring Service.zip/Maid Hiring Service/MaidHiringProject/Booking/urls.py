from django.urls import path
from . views import *

app_name = 'Booking'

urlpatterns = [
    path('view_maid/', View_Maid, name='view_maid'),

]

