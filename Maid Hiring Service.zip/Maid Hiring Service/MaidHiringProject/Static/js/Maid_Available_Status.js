document.addEventListener("DOMContentLoaded", () => {
    const switchElement = document.getElementById("availabilitySwitch");
    const labelElement = document.getElementById("availabilityLabel");

    switchElement.addEventListener("change", () => {
        const isAvailable = switchElement.checked;

        // Update label text and color
        labelElement.textContent = isAvailable ? "Active" : "Inactive";
        labelElement.style.color = isAvailable ? "green" : "red";

        // Send AJAX request to update availability
        fetch(updateAvailabilityUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrfToken,
            },
            body: JSON.stringify({ available: isAvailable }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log("Availability updated successfully!");
                } else {
                    console.log("Failed to update availability.");
                }
            })
            .catch(error => {
                console.error("Error updating availability:", error);
            });
    });
});
