from django.urls import path
from . views import *

app_name = 'Maid'

urlpatterns = [
    path('', Maid_Dashboard, name='maid_home'),
    path('maid_register/', Maid_Register, name='maid_register'),
    path('profile/', maid_profile, name='maid_profile'),
    path('maid_logout/', Maid_Logout, name='maid_logout'),
    path('change-password/', Change_Password, name='change_password'),
    path('update_availability/', Update_Availability, name='update_availability'),
    path('customer-requests/', View_Customer_Requests, name='view_customer_requests'),
    path('handle-request/', Handle_Request, name='handle_request'),
    path('accepted-requests/', Accepted_Requests, name='accepted_requests'),
]

