from django.contrib import admin
from . models import *
# Register your models here.

admin.site.register(JobType)

@admin.register(MaidDetails)
class MaidDetailsAdmin(admin.ModelAdmin):
    list_display = ('id', 'first_name', 'last_name', 'age', 'phone', 'is_available', 'is_approved')
    list_filter = ('is_approved',)
    search_fields = ('first_name', 'last_name', 'email')
    list_editable = ('is_approved',)
    actions = ['approve_maids']

    def approve_maids(self, request, queryset):
        queryset.update(is_approved=True)
        self.message_user(request, "Selected maids have been approved.")
    approve_maids.short_description = "Approve selected maids"


class CategoryAdmin(admin.ModelAdmin):
    prepopulated_fields = {"link":['name',]}
admin.site.register(JobPosition, CategoryAdmin)



