from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from Customer.models import ConnectionRequest, UserProfile
from django.http import HttpResponseForbidden
from . forms import *
from . models import *

# Create your views here.

@login_required(login_url='Maid:maid_login')
def Maid_Dashboard(request):
    maid = get_object_or_404(MaidDetails, id=request.user.id)
    return render(request, 'Maid/Dashboard.html', {"maid": maid})


def Maid_Register(request):
    if request.method == 'POST':
        form = MaidRegistrationForm(request.POST, request.FILES)
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')

        if password != repassword:
            messages.error(request, "Passwords do not match.")
        elif form.is_valid():
            try:
                user = User.objects.create_user(
                    username=form.cleaned_data['email'],
                    email=form.cleaned_data['email'],
                    password=password,
                    first_name=form.cleaned_data['first_name'],
                    last_name=form.cleaned_data['last_name'],
                )
                user.save()

                UserProfile.objects.create(user=user, is_maid=True)

                maid = form.save(commit=False)
                maid.id = user
                maid.is_approved = False
                maid.save()
                form.save_m2m()

                messages.success(request, 'Registration successful! Please wait for admin approval.')
                return redirect('Customer:login')  # Unified login URL
            except Exception as e:
                messages.error(request, f"Error during registration: {e}")
        else:
            messages.error(request, "Invalid form data.")
    else:
        form = MaidRegistrationForm()

    return render(request, 'Maid/register.html', {'form': form})

def Maid_Logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('Customer:login')


@login_required(login_url='Maid:maid_login')
def maid_profile(request):
    try:
        maid = MaidDetails.objects.get(id=request.user)
    except MaidDetails.DoesNotExist:
        maid = None

    if request.method == 'POST':
        form = MaidRegistrationForm(request.POST, request.FILES, instance=maid)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.id = request.user
            profile.save()
            form.save_m2m()
            messages.success(request, "Profile updated successfully!")
            return redirect('Maid:maid_profile')
        else:
            messages.error(request, "Error updating profile. Please correct the highlighted fields.")
    else:
        form = MaidRegistrationForm(instance=maid)

    return render(request, 'Maid/Profile.html', {'form': form})


@login_required(login_url='Maid:maid_login')
def Change_Password(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, request.user)  # Prevent user from being logged out
            messages.success(request, "Your password was successfully updated!")
            return redirect('Maid:maid_profile')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = CustomPasswordChangeForm(user=request.user)

    return render(request, 'Maid/Change_Password.html', {'form': form})



@csrf_exempt
@login_required(login_url='Maid:maid_login')
def Update_Availability(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            is_available = data.get("available", False)

            maid = get_object_or_404(MaidDetails, id=request.user.id)
            maid.is_available = is_available
            maid.save()
            print(f"User: {request.user.username}, Is Available: {is_available}")
            return JsonResponse({"success": True, "is_available": maid.is_available})

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)}, status=400)

    return JsonResponse({"success": False}, status=400)


@login_required(login_url='Maid:maid_login')
def View_Customer_Requests(request):
    # Get the current logged-in maid's details
    maid = request.user.maiddetails  # Assuming maid is logged in, and `MaidDetails` has a OneToOne relation with `User`.

    # Fetch all requests for the logged-in maid
    requests = ConnectionRequest.objects.filter(maid=maid, status="Pending").order_by('-id')

    return render(request, 'Maid/Customer_Request.html', {'requests': requests})


@login_required(login_url='Maid:maid_login')
def Handle_Request(request):
    if request.method == 'POST':
        request_id = request.POST.get('request_id')
        action = request.POST.get('action')

        connection_request = get_object_or_404(ConnectionRequest, id=request_id)

        # Check if the current user is the assigned maid
        if connection_request.maid != request.user.maiddetails:
            return HttpResponseForbidden("You are not authorized to perform this action.")

        # Update the request status based on the action
        if action == 'accept':
            connection_request.status = 'Accepted'
        elif action == 'reject':
            connection_request.status = 'Rejected'
        connection_request.save()

        return redirect('Maid:view_customer_requests')


@login_required(login_url='Maid:maid_login')
def Accepted_Requests(request):
    accepted_requests = ConnectionRequest.objects.filter(maid=request.user.maiddetails, status='Accepted')
    return render(request, 'Maid/Accepted_Requests.html', {'accepted_requests': accepted_requests})
