from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
# Create your models here.


class MaidDetails(models.Model):
    JOB_POSITION_CHOICES = [
        ('Cooking', 'Cooking'),
        ('Cleaning', 'Cleaning'),
        ('Babysitting', 'Babysitting'),
        ('Other', 'Other'),
    ]

    JOB_TYPE_CHOICES = [
        ('Full-time', 'Full-time'),
        ('Part-time', 'Part-time'),
        ('Contract Based', 'Contract Based'),
    ]

    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
    ]

    id = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    age = models.PositiveIntegerField()
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    street = models.CharField(max_length=100)
    district = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    job_position = models.ManyToManyField('JobPosition')
    job_type = models.ManyToManyField('JobType')
    photo = models.ImageField(upload_to='maids/', null=True, blank=True)
    is_available = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class JobPosition(models.Model):
    name = models.CharField(max_length=50, unique=True)
    link = models.SlugField(unique=True)

    def __str__(self):
        return self.name


class JobType(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

