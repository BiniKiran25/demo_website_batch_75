from django import forms
from . models import MaidDetails, JobPosition, JobType


class MaidRegistrationForm(forms.ModelForm):
    job_position = forms.ModelMultipleChoiceField(
        queryset=JobPosition.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )
    job_type = forms.ModelMultipleChoiceField(
        queryset=JobType.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    class Meta:
        model = MaidDetails
        fields = [
            'first_name', 'last_name', 'age', 'phone', 'email', 'gender', 'street',
            'district', 'city', 'job_position', 'job_type', 'photo'
        ]



class CustomPasswordChangeForm(forms.Form):
    old_password = forms.CharField(
        label="Old password",
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True,
    )
    new_password1 = forms.CharField(
        label="New password",
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True,
    )
    new_password2 = forms.CharField(
        label="New password confirmation",
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True,
    )

    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)

    def clean_old_password(self):
        old_password = self.cleaned_data.get("old_password")
        if not self.user.check_password(old_password):
            raise forms.ValidationError("Your old password was entered incorrectly. Please try again.")
        return old_password

    def clean(self):
        cleaned_data = super().clean()
        new_password1 = cleaned_data.get("new_password1")
        new_password2 = cleaned_data.get("new_password2")

        if new_password1 and new_password2 and new_password1 != new_password2:
            raise forms.ValidationError("The two password fields didn’t match.")

        return cleaned_data

    def save(self, commit=True):
        new_password = self.cleaned_data["new_password1"]
        self.user.set_password(new_password)
        if commit:
            self.user.save()
        return self.user