from .models import MaidDetails


def maid_availability(request):
    if request.user.is_authenticated:
        try:
            maid = MaidDetails.objects.get(id=request.user.id)
            return {"maid_is_available": maid.is_available}
        except MaidDetails.DoesNotExist:
            return {}
    return {}

