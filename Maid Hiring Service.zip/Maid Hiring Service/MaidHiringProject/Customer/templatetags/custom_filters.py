from django import template
from Customer.models import ConnectionRequest
from Maid.models import MaidDetails
register = template.Library()

@register.filter
def get_status(maid_id, user):
    try:
        # Ensure `maid_id` corresponds to a MaidDetails instance
        maid = MaidDetails.objects.get(id=maid_id)
        request = ConnectionRequest.objects.filter(maid=maid, customer=user).first()
        if request:
            return request.status
    except MaidDetails.DoesNotExist:
        return None
    return None