from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.urls import reverse
from django.contrib import messages
from django.db.models import Q
from .models import *
from .forms import *
from Maid.models import MaidDetails, JobPosition
from datetime import datetime, timedelta
# Create your views here.

def Home(request):
    return render(request, 'Home/index.html')

def Contact(request):
    return render(request, 'Home/contact.html')

def About(request):
    return render(request, 'Home/about.html')


def Customer_Register(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        repassword = request.POST.get('repassword')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        street = request.POST.get('street')
        district = request.POST.get('district')
        city = request.POST.get('city')
        photo = request.FILES.get('c_image')

        # Password match validation
        if password != repassword:
            messages.error(request, "Passwords do not match!")
            return redirect('Customer:customer_register')

        # Email uniqueness validation
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
            return redirect('Customer:customer_register')

        # Phone validation
        if not phone.isdigit() or len(phone) != 10:
            messages.error(request, "Phone number must be 10 digits!")
            return redirect('Customer:customer_register')

        # Date of birth validation (age >= 18)
        try:
            dob_datetime = datetime.strptime(dob, "%Y-%m-%d")
            age = (datetime.now() - dob_datetime).days // 365
            if age < 18:
                messages.error(request, "You must be at least 18 years old to register!")
                return redirect('Customer:customer_register')
        except ValueError:
            messages.error(request, "Invalid date format for Date of Birth!")
            return redirect('Customer:customer_register')

        try:
            # Create User and CustomerDetails records
            user = User.objects.create_user(
                username=email,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
            )
            user.save()

            UserProfile.objects.create(user=user, is_customer=True)  # Add role here

            customer = CustomerDetails(
                id=user,
                first_name=first_name,
                last_name=last_name,
                phone=phone,
                email=email,
                gender=gender,
                dob=dob,
                street=street,
                district=district,
                city=city,
                photo=photo
            )
            customer.save()

            messages.success(request, "Registration successful!")
            return redirect('Customer:login')  # Unified login URL
        except Exception as e:
            messages.error(request, f"An error occurred: {e}")
            return redirect('Customer:customer_register')

    return render(request, 'Customer/Register.html')

def unified_login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = authenticate(username=email, password=password)

        if user:
            try:
                profile = UserProfile.objects.get(user=user)
                if profile.is_maid:
                    maid = MaidDetails.objects.get(id=user)
                    if not maid.is_approved:
                        messages.error(request, 'Your account is not approved by the admin.')
                        return redirect('Customer:login')
                login(request, user)

                if profile.is_maid:
                    return redirect('Maid:maid_home')
                elif profile.is_customer:
                    return redirect('Customer:home')
            except (UserProfile.DoesNotExist, MaidDetails.DoesNotExist):
                messages.error(request, 'User profile not found.')
        else:
            messages.error(request, 'Invalid email or password.')

    return render(request, 'Customer/Login.html')


def Customer_Logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('Customer:login')


@login_required(login_url='Customer:customer_login')
def Customer_Profile(request):
    try:
        customer = CustomerDetails.objects.get(id=request.user)
    except CustomerDetails.DoesNotExist:
        customer = None

    if request.method == 'POST':
        form = CustomerProfileForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.id = request.user
            profile.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('Customer:customer_profile')
        else:
            messages.error(request, "Error updating profile. Please correct the highlighted fields.")
    else:
        form = CustomerProfileForm(instance=customer)

    return render(request, 'Customer/Profile.html', {'form': form})


@login_required(login_url='Customer:customer_login')
def Change_Password(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, request.user)
            messages.success(request, "Your password was successfully updated!")
            return redirect('Customer:customer_profile')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = CustomPasswordChangeForm(user=request.user)

    return render(request, 'Customer/Change_Password.html', {'form': form})



@login_required(login_url='Customer:customer_login')
def View_Maid(request):
    maids = MaidDetails.objects.filter(is_approved=True)
    connection_requests = ConnectionRequest.objects.filter(customer=request.user)
    request_status = {req.maid.id: req.status for req in connection_requests}

    return render(request, 'Customer/All_Maid.html', {
        'maids': maids,
        'request_status': request_status,
    })


@login_required(login_url='Customer:customer_login')
def position_details(request, link=None):
    cat = JobPosition.objects.get(link=link)
    maids = MaidDetails.objects.filter(job_position=cat)
    return render(request, 'Customer/All_Maid.html', {'maids': maids})


@login_required(login_url='Customer:customer_login')
def send_request(request):
    if request.method == 'POST':
        maid_id = request.POST.get('maid_id')
        maid = get_object_or_404(MaidDetails, pk=maid_id)
        print(maid_id,maid)

        if ConnectionRequest.objects.filter(customer=request.user, maid=maid, status='Pending').exists():
            print("Connection request already exists.")
            return redirect('Customer:view_maid')

        connection_request = ConnectionRequest(customer=request.user, maid=maid)
        connection_request.save()
        return HttpResponseRedirect(reverse('Customer:view_maid'))


@login_required
def handle_request(request, request_id, action):
    connection_request = get_object_or_404(ConnectionRequest, id=request_id, maid=request.user)
    if action == 'accept':
        connection_request.status = 'Accepted'
    elif action == 'reject':
        connection_request.status = 'Rejected'
    connection_request.save()
    return redirect('Customer:view_maid')


@login_required(login_url='Customer:customer_login')
def Accepted_Maids(request):
    accepted_requests = ConnectionRequest.objects.filter(customer=request.user, status='Accepted').select_related('maid')
    return render(request, 'Customer/Accepted_Maids.html', {'accepted_requests': accepted_requests})


@login_required(login_url='Customer:customer_login')
def filter_maids(request):
    print("Request GET Data:", request.GET)
    filters = request.GET.getlist('filters')
    print("Received filters:", filters)

    maids = MaidDetails.objects.filter(is_approved=True)

    # Apply filters to the queryset if the filters are selected
    if 'availability_true' in filters:
        maids = maids.filter(is_available=True)
    if 'availability_false' in filters:
        maids = maids.filter(is_available=False)
    if 'gender_m' in filters:
        maids = maids.filter(gender='M')
    if 'gender_f' in filters:
        maids = maids.filter(gender='F')

    # Apply filters for Job Positions (Many-to-Many relation)
    job_position_filters = [
        ('job_position_cooking', 'Cooking'),
        ('job_position_cleaning', 'Cleaning'),
        ('job_position_babysitting', 'Babysitting'),
        ('job_position_other', 'Other')
    ]

    for filter_key, position_name in job_position_filters:
        if filter_key in filters:
            maids = maids.filter(job_position__name=position_name)

    # Apply filters for Job Types (Many-to-Many relation)
    job_type_filters = [
        ('job_type_full_time', 'Full-time'),
        ('job_type_part_time', 'Part-time'),
        ('job_type_contract', 'Contract Based')
    ]

    for filter_key, job_type_name in job_type_filters:
        if filter_key in filters:
            maids = maids.filter(job_type__name=job_type_name)

    return render(request, 'Customer/All_Maid.html', {'maids': maids})


@login_required(login_url='Customer:customer_login')
def Maid_Search(request):
    query = request.GET.get('q', '').strip()
    print(f"Query received: {query}")

    if query:
        results = MaidDetails.objects.filter(
            Q(district__icontains=query), is_approved=True
        )
    else:
        results = []

    return render(request, 'Customer/All_Maid.html', {'maids': results})