from Maid.models import JobPosition
from . models import ConnectionRequest


def category_context(request):
    job_positions = JobPosition.objects.all()

    return {'job_positions': job_positions,}


def request_status(request):
    if request.user.is_authenticated:
        connection_requests = ConnectionRequest.objects.filter(customer=request.user)
        request_status = {req.maid.id: req.status for req in connection_requests}
    else:
        request_status = {}
    return {'request_status': request_status}