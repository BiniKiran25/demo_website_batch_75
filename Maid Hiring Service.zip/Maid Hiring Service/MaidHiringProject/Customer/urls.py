from django.urls import path
from . views import *

app_name = 'Customer'

urlpatterns = [
    path('', Home, name='home'),
    path('about/', About, name='about'),
    path('contact/', Contact, name='contact'),
    path('customer_register/', Customer_Register, name='customer_register'),
    path('login/', unified_login, name='login'),
    path('customer_logout/', Customer_Logout, name='customer_logout'),
    path('customer_profile/', Customer_Profile, name='customer_profile'),
    path('change-password/', Change_Password, name='change_password'),
    path('view_maid/', View_Maid, name='view_maid'),
    path('position/<slug:link>/', position_details, name='position_details'),
    path('send_request/', send_request, name='send_request'),
    # path('connections/', views.connection_list, name='connection_list'),
    path('handle_request/<int:request_id>/<str:action>/', handle_request, name='handle_request'),
    path('accepted-maids/', Accepted_Maids, name='accepted_maids'),
    path('filter/',filter_maids, name='filter_maids'),
    path('maid_search/', Maid_Search, name='maid_search'),

]

