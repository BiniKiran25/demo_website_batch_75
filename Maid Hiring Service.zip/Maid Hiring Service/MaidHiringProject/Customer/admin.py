from django.contrib import admin
from .models import CustomerDetails, ConnectionRequest, UserProfile


@admin.register(CustomerDetails)
class CustomerDetailsAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'phone', 'gender', 'dob', 'district', 'city')
    search_fields = ('first_name', 'last_name', 'email', 'phone')
    list_filter = ('gender', 'district', 'city')
    ordering = ('id',)


@admin.register(ConnectionRequest)
class ConnectionRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer__first_name', 'maid', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('customer__first_name', 'maid__first_name', 'status')
    ordering = ('-created_at',)


class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_maid', 'is_customer')  # Columns to display
    search_fields = ('user__username', 'user__email')  # Searchable fields
    list_filter = ('is_maid', 'is_customer')  # Filter options
    readonly_fields = ('user',)  # Make 'user' field read-only
admin.site.register(UserProfile, UserProfileAdmin)

